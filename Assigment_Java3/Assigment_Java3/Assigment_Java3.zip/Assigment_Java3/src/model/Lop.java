/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author admin
 */
public class Lop {

    private int id;
    private SinhVien sinhVien;
    private int tiengAnh;
    private int tinHoc;
    private int gdtc;
    private int diemTB;

    public Lop() {
    }

    public Lop(int id, SinhVien sinhVien, int tiengAnh, int tinHoc, int gdtc, int diemTB) {
        this.id = id;
        this.sinhVien = sinhVien;
        this.tiengAnh = tiengAnh;
        this.tinHoc = tinHoc;
        this.gdtc = gdtc;
        this.diemTB = diemTB;
    }

    public Lop(int tiengAnh, int tinHoc, int gdtc) {
        this.tiengAnh = tiengAnh;
        this.tinHoc = tinHoc;
        this.gdtc = gdtc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public SinhVien getSinhVien() {
        return sinhVien;
    }

    public void setSinhVien(SinhVien sinhVien) {
        this.sinhVien = sinhVien;
    }

    public int getTiengAnh() {
        return tiengAnh;
    }

    public void setTiengAnh(int tiengAnh) {
        this.tiengAnh = tiengAnh;
    }

    public int getTinHoc() {
        return tinHoc;
    }

    public void setTinHoc(int tinHoc) {
        this.tinHoc = tinHoc;
    }

    public int getGdtc() {
        return gdtc;
    }

    public void setGdtc(int gdtc) {
        this.gdtc = gdtc;
    }

    public int getDiemTB() {
        return diemTB;
    }

    public void setDiemTB(int diemTB) {
        this.diemTB = diemTB;
    }

    @Override
    public String toString() {
        return "Lop{" + "id=" + id + ", sinhVien=" + sinhVien + ", tiengAnh=" + tiengAnh + ", tinHoc=" + tinHoc + ", gdtc=" + gdtc + ", diemTB=" + diemTB + '}';
    }

    public Object[] toDataRow() {
        return new Object[]{sinhVien.getMaSV(), sinhVien.getHoTen(), tiengAnh, tinHoc, gdtc, diemTB};
    }

}
