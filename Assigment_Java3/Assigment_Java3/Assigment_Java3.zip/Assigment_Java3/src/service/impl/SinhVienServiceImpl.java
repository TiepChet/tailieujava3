/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service.impl;

import java.util.List;
import model.SinhVien;
import reposition.SinhVienReposition;
import service.SinhVienService;

/**
 *
 * @author admin
 */
public class SinhVienServiceImpl implements SinhVienService {

    private SinhVienReposition svr = new SinhVienReposition();

    @Override
    public List<SinhVien> getAll() {
        return svr.getAll();
    }

    @Override
    public String add(SinhVien sv) {
        boolean add = svr.add(sv);
        if (add) {
            return "Add Thành Công";
        } else {
            return "Add Thất Bại";
        }
    }

    @Override
    public String delete(String maSV) {
        boolean delete = svr.delete(maSV);
        if (delete) {
            return "Delete Thành Công";
        } else {
            return "Delete Thất Bại";
        }
    }

    @Override
    public String update(SinhVien sv, String maSV) {
        boolean update = svr.update(sv, maSV);
        if (update) {
            return "Update Thành Công";
        } else {
            return "Update Thất Bại";
        }
    }

}
