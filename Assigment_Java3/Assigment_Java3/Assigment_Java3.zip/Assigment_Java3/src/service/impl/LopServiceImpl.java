/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service.impl;

import java.util.List;
import model.Lop;
import model.SinhVien;
import reposition.LopReposition;
import service.LopService;

/**
 *
 * @author admin
 */
public class LopServiceImpl implements LopService {

    private LopReposition gr = new LopReposition();

    @Override
    public List<Lop> getAll() {
        return gr.getAll();
    }

    @Override
    public List<Lop> search(String maSV) {
        return gr.search(maSV);
    }

    @Override
    public String add(Lop l) {
        boolean add = gr.add(l);
        if (add) {
            return "Add Thành Công";
        } else {
            return "Add Thất Bại";
        }
    }

    @Override
    public String delete(String maSV) {
        boolean delete = gr.delete(maSV);
        if (delete) {
            return "Delete Thành Công";
        } else {
            return "Delete Thất Bại";
        }
    }

    @Override
    public String update(Lop l, int tiengAnh) {
        boolean update = gr.update(l, tiengAnh);
        if (update) {
            return "Update Thành Công";
        } else {
            return "Update Thất Bại";
        }
    }
}
