/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;
import model.Lop;

/**
 *
 * @author admin
 */
public interface LopService {

    List<Lop> getAll();

    List<Lop> search(String maSV);

    String add(Lop l);

    String delete(String maSV);

    String update(Lop l, int tiengAnh);

}
