/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reposition;

import java.util.List;
import model.SinhVien;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class SinhVienReposition {

    public List<SinhVien> getAll() {
        String query = "select s.maSV, s.hoTen, s.email, s.soDT, s.gioiTinh, s.diaChi\n"
                + "from student s";
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {
            List<SinhVien> listSinhVien = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SinhVien sv = new SinhVien(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getBoolean(5), rs.getString(6));
                listSinhVien.add(sv);
            }
            return listSinhVien;
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public boolean add(SinhVien sv) {
        String query = "INSERT INTO [dbo].[student]\n"
                + "           ([maSV]\n"
                + "           ,[hoTen]\n"
                + "           ,[email]\n"
                + "           ,[soDT]\n"
                + "           ,[gioiTinh]\n"
                + "           ,[diaChi])\n"
                + "     VALUES\n"
                + "           (?,?,?,?,?,?)";
        int check = 0;
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setObject(1, sv.getMaSV());
            ps.setObject(2, sv.getHoTen());
            ps.setObject(3, sv.getEmail());
            ps.setObject(4, sv.getSoDienThoai());
            ps.setObject(5, sv.isGioiTinh());
            ps.setObject(6, sv.getDiaChi());
            check = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }

    public boolean update(SinhVien sv, String maSV) {
        String query = "UPDATE [dbo].[student]\n"
                + "      SET [hoTen] = ?"
                + "      ,[email] = ?"
                + "      ,[soDT] = ?"
                + "      ,[gioiTinh] = ?"
                + "      ,[diaChi] = ?"
                + " WHERE maSV like ?";
        int check = 0;
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setObject(1, sv.getHoTen());
            ps.setObject(2, sv.getEmail());
            ps.setObject(3, sv.getSoDienThoai());
            ps.setObject(4, sv.isGioiTinh());
            ps.setObject(5, sv.getDiaChi());
            ps.setObject(6, maSV);

            check = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }

    public boolean delete(String maSV) {
        String query = "DELETE FROM [dbo].[student]\n"
                + "      WHERE maSV like ?";
        int check = 0;
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setObject(1, maSV);
            check = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }
}
