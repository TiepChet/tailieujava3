/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reposition;

import java.util.List;
import model.Lop;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.SinhVien;

/**
 *
 * @author admin
 */
public class LopReposition {

    public List<Lop> getAll() {
        String query = "select g.id, s.maSV,s.hoTen,s.email,s.soDT, s.gioiTinh,s.diaChi, g.tiengAnh, g.tinHoc, g.gdtc, avg(g.tiengAnh+g.tinHoc + g.gdtc)/3 as'dtb'\n"
                + "from grade g, student s\n"
                + "where g.maSV = s.maSV\n"
                + "group by g.id, s.maSV,s.hoTen,s.email,s.soDT, s.gioiTinh,s.diaChi, g.tiengAnh, g.tinHoc, g.gdtc";
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {
            List<Lop> listLop = new ArrayList<>();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SinhVien sv = new SinhVien(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getBoolean(6), rs.getString(7));
                Lop lop = new Lop(rs.getInt(1), sv, rs.getInt(8), rs.getInt(9), rs.getInt(10), rs.getInt(11));
                listLop.add(lop);
            }
            return listLop;
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;

    }

    public List<Lop> search(String maSV) {
        String query = "select g.id, s.maSV,s.hoTen,s.email,s.soDT, s.gioiTinh,s.diaChi, g.tiengAnh, g.tinHoc, g.gdtc, avg(g.tiengAnh+g.tinHoc + g.gdtc)/3 as'dtb'\n"
                + "from grade g, student s\n"
                + "where g.maSV = s.maSV  and s.maSV like ?\n"
                + "group by g.id, s.maSV,s.hoTen,s.email,s.soDT, s.gioiTinh,s.diaChi, g.tiengAnh, g.tinHoc, g.gdtc";
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {
            List<Lop> listLop = new ArrayList<>();
            ps.setObject(1, maSV);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SinhVien sv = new SinhVien(rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getBoolean(6), rs.getString(7));
                Lop lop = new Lop(rs.getInt(1), sv, rs.getInt(8), rs.getInt(9), rs.getInt(10), rs.getInt(11));
                listLop.add(lop);
            }
            return listLop;
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    public boolean add(Lop l) {
        String query = "INSERT INTO [dbo].[grade]\n"
                + "           ([maSV]\n"
                + "           ,[tiengAnh]\n"
                + "           ,[tinHoc]\n"
                + "           ,[gdtc])\n"
                + "     VALUES\n"
                + "           (?,?,?,?)";
        int check = 0;
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setObject(1, l.getSinhVien().getMaSV());
            ps.setObject(2, l.getTiengAnh());
            ps.setObject(3, l.getTinHoc());
            ps.setObject(4, l.getGdtc());
            check = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }

    public boolean delete(String maSV) {
        String query = "DELETE FROM [dbo].[grade]\n"
                + "      WHERE maSV like ?";
        int check = 0;
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setObject(1, maSV);
            check = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }

    public boolean update(Lop l, int tiengAnh) {
        String query = "UPDATE [dbo].[grade]\n"
                + "      SET [tinHoc] = ?"
                + "      ,[gdtc] = ?"
                + " WHERE tiengAnh like ?";
        int check = 0;
        try (Connection conn = SQLServerConnection.getConnection();
                PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setObject(1, l.getTinHoc());
            ps.setObject(2, l.getGdtc());
            ps.setObject(3, tiengAnh);
            check = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return check > 0;
    }
}
